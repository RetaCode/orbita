(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_sweetalert2_dist_sweetalert2_all_9b11db5c.js",
  "static/chunks/node_modules_next_0766a282._.js",
  "static/chunks/node_modules_motion-dom_dist_es_27804559._.js",
  "static/chunks/node_modules_framer-motion_dist_es_547832d8._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_tsparticles-engine_esm_627710d3._.js",
  "static/chunks/node_modules_a52b2561._.js",
  "static/chunks/_faa71ad2._.js"
],
    source: "dynamic"
});
